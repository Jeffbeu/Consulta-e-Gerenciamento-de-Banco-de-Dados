-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 27-Jan-2020 às 15:44
-- Versão do servidor: 10.1.38-MariaDB
-- versão do PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `locadora`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `ator`
--

CREATE TABLE `ator` (
  `codAtor` int(11) NOT NULL,
  `nomeAtor` varchar(100) DEFAULT NULL,
  `codFilme` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `idCliente` int(11) NOT NULL,
  `emailCliente` varchar(100) DEFAULT NULL,
  `telCliente` varchar(10) DEFAULT NULL,
  `enderecoCliente` varchar(100) DEFAULT NULL,
  `dependente` varchar(100) DEFAULT NULL,
  `cpfCliente` varchar(15) DEFAULT NULL,
  `nomeCliente` varchar(100) DEFAULT NULL,
  `cnpj` varchar(20) DEFAULT NULL,
  `razaoSocial` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `elenco`
--

CREATE TABLE `elenco` (
  `codElenco` int(11) NOT NULL,
  `codAtor` int(11) DEFAULT NULL,
  `codFilme` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `filme`
--

CREATE TABLE `filme` (
  `codFilme` int(11) NOT NULL,
  `nomeFilme` varchar(100) DEFAULT NULL,
  `duracao` varchar(20) DEFAULT NULL,
  `classificacao` varchar(20) DEFAULT NULL,
  `genero` varchar(20) DEFAULT NULL,
  `precoAluguel` double DEFAULT NULL,
  `codCliente` int(11) DEFAULT NULL,
  `codFornecedor` int(11) DEFAULT NULL,
  `idcliente` int(11) DEFAULT NULL,
  `codAtor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedor`
--

CREATE TABLE `fornecedor` (
  `codFornecedor` int(11) NOT NULL,
  `razaoSocial` varchar(100) DEFAULT NULL,
  `cnpjFornecedor` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamento`
--

CREATE TABLE `pagamento` (
  `codPagamento` int(11) NOT NULL,
  `valorPagamento` double DEFAULT NULL,
  `descricao` varchar(100) DEFAULT NULL,
  `formaPagamento` varchar(20) DEFAULT NULL,
  `dataPagamento` date DEFAULT NULL,
  `idCliente` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ator`
--
ALTER TABLE `ator`
  ADD PRIMARY KEY (`codAtor`),
  ADD KEY `codFilme` (`codFilme`);

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idCliente`),
  ADD UNIQUE KEY `cpfCliente` (`cpfCliente`),
  ADD UNIQUE KEY `cnpj` (`cnpj`),
  ADD UNIQUE KEY `emailCliente` (`emailCliente`);

--
-- Indexes for table `elenco`
--
ALTER TABLE `elenco`
  ADD PRIMARY KEY (`codElenco`),
  ADD KEY `codAtor` (`codAtor`),
  ADD KEY `codFilme` (`codFilme`);

--
-- Indexes for table `filme`
--
ALTER TABLE `filme`
  ADD PRIMARY KEY (`codFilme`),
  ADD KEY `codFornecedor` (`codFornecedor`),
  ADD KEY `codAtor` (`codAtor`);

--
-- Indexes for table `fornecedor`
--
ALTER TABLE `fornecedor`
  ADD PRIMARY KEY (`codFornecedor`),
  ADD UNIQUE KEY `cnpjFornecedor` (`cnpjFornecedor`);

--
-- Indexes for table `pagamento`
--
ALTER TABLE `pagamento`
  ADD PRIMARY KEY (`codPagamento`),
  ADD KEY `fk_pagamento` (`idCliente`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `elenco`
--
ALTER TABLE `elenco`
  MODIFY `codElenco` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `filme`
--
ALTER TABLE `filme`
  MODIFY `codFilme` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fornecedor`
--
ALTER TABLE `fornecedor`
  MODIFY `codFornecedor` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pagamento`
--
ALTER TABLE `pagamento`
  MODIFY `codPagamento` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `ator`
--
ALTER TABLE `ator`
  ADD CONSTRAINT `ator_ibfk_1` FOREIGN KEY (`codFilme`) REFERENCES `filme` (`codFilme`);

--
-- Limitadores para a tabela `elenco`
--
ALTER TABLE `elenco`
  ADD CONSTRAINT `elenco_ibfk_1` FOREIGN KEY (`codAtor`) REFERENCES `ator` (`codAtor`),
  ADD CONSTRAINT `elenco_ibfk_2` FOREIGN KEY (`codFilme`) REFERENCES `filme` (`codFilme`);

--
-- Limitadores para a tabela `filme`
--
ALTER TABLE `filme`
  ADD CONSTRAINT `filme_ibfk_1` FOREIGN KEY (`codFornecedor`) REFERENCES `fornecedor` (`codFornecedor`),
  ADD CONSTRAINT `filme_ibfk_2` FOREIGN KEY (`codAtor`) REFERENCES `ator` (`codAtor`),
  ADD CONSTRAINT `fk_filme` FOREIGN KEY (`codFornecedor`) REFERENCES `fornecedor` (`codFornecedor`);

--
-- Limitadores para a tabela `pagamento`
--
ALTER TABLE `pagamento`
  ADD CONSTRAINT `fk_pagamento` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
