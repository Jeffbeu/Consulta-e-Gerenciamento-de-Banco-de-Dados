-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 07-Fev-2020 às 15:44
-- Versão do servidor: 10.4.6-MariaDB
-- versão do PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `avaliacao4`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `codCliente` int(11) NOT NULL,
  `nomeCliente` varchar(50) DEFAULT NULL,
  `cpfCliente` varchar(11) DEFAULT NULL,
  `identidadeCliente` varchar(9) DEFAULT NULL,
  `emailCliente` varchar(30) DEFAULT NULL,
  `telefoneCliente` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`codCliente`, `nomeCliente`, `cpfCliente`, `identidadeCliente`, `emailCliente`, `telefoneCliente`) VALUES
(1, 'Jose Carlos', '12345678910', '123456789', '123@gmail.com', '985851212'),
(2, 'Carlos José', '12345678911', '123456788', '456@gmail.com', '985851213'),
(3, 'Jorge Mário', '12345678912', '123456787', '789@gmail.com', '985851211'),
(4, 'Mário Jorge', '12345678913', '123456786', '321@gmail.com', '985851214');

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedor`
--

CREATE TABLE `fornecedor` (
  `codFornecedor` int(11) NOT NULL,
  `cnpj` varchar(14) DEFAULT NULL,
  `razaoSocial` varchar(30) DEFAULT NULL,
  `rua` varchar(30) DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `bairro` varchar(30) DEFAULT NULL,
  `municipio` varchar(30) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `cep` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `fornecedor`
--

INSERT INTO `fornecedor` (`codFornecedor`, `cnpj`, `razaoSocial`, `rua`, `num`, `bairro`, `municipio`, `estado`, `cep`) VALUES
(1, '123', 'Lira’s', 'Sul', 2, 'Méier', 'Rio de Janeiro', 'RJ', '20987030'),
(2, '654', 'Killer', 'Sul', 3, 'Galo', 'São Paulo', 'SP', '20987031'),
(3, '987', 'Life', 'Leste', 4, 'Ilha', 'Rio de Janeiro', 'RJ', '20987032'),
(4, '147', 'Board', 'Oeste', 5, 'Tamandaré', 'São Paulo', 'SP', '20987033'),
(5, '258', 'Inforway', 'Sudoeste', 6, 'Lapa', 'Cuiabá', 'MT', '20987034'),
(6, '369', 'José Castro', 'Nordeste', 7, 'Alcantara', 'São Gonçalo', 'RJ', '20987035');

-- --------------------------------------------------------

--
-- Estrutura da tabela `livro`
--

CREATE TABLE `livro` (
  `codLivro` int(11) NOT NULL,
  `titulo` varchar(30) DEFAULT NULL,
  `editora` varchar(30) DEFAULT NULL,
  `precoLivro` double DEFAULT NULL,
  `codCliente` int(11) DEFAULT NULL,
  `codFornecedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `livro`
--

INSERT INTO `livro` (`codLivro`, `titulo`, `editora`, `precoLivro`, `codCliente`, `codFornecedor`) VALUES
(1, 'Alice Encantada', 'Ética', 78, NULL, NULL),
(2, '300 tons de vermelho', 'Abril', 45, NULL, NULL),
(3, 'Um homem atrás da árvore', 'Life', 98, NULL, NULL),
(4, 'O secador de gelo', 'Selfie', 124, NULL, NULL),
(5, 'O Cavalo Manco', 'Calipso', 34, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamento`
--

CREATE TABLE `pagamento` (
  `codPagamento` int(11) NOT NULL,
  `descricaoPagamento` varchar(30) DEFAULT NULL,
  `valor` double DEFAULT NULL,
  `dataPagamento` date DEFAULT NULL,
  `formaPagamento` varchar(30) DEFAULT NULL,
  `codCliente` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `pagamento`
--

INSERT INTO `pagamento` (`codPagamento`, `descricaoPagamento`, `valor`, `dataPagamento`, `formaPagamento`, `codCliente`) VALUES
(1, 'Alice Encantada', 78, NULL, 'Cartão', NULL),
(2, '300 tons de vermelho', 45, NULL, 'Dinheiro', NULL),
(3, 'Um homem atrás da árvore', 98, NULL, 'Cartão', NULL),
(4, 'O secador de gelo', 124, NULL, 'Dinheiro', NULL),
(5, 'O Cavalo Manco', 34, NULL, 'Cartão', NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`codCliente`),
  ADD UNIQUE KEY `cpfCliente` (`cpfCliente`),
  ADD UNIQUE KEY `identidadeCliente` (`identidadeCliente`);

--
-- Índices para tabela `fornecedor`
--
ALTER TABLE `fornecedor`
  ADD PRIMARY KEY (`codFornecedor`),
  ADD UNIQUE KEY `cnpj` (`cnpj`);

--
-- Índices para tabela `livro`
--
ALTER TABLE `livro`
  ADD PRIMARY KEY (`codLivro`),
  ADD KEY `fk_clientex` (`codCliente`),
  ADD KEY `fk_fornecedor` (`codFornecedor`);

--
-- Índices para tabela `pagamento`
--
ALTER TABLE `pagamento`
  ADD PRIMARY KEY (`codPagamento`),
  ADD KEY `fk_cliente` (`codCliente`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `codCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `fornecedor`
--
ALTER TABLE `fornecedor`
  MODIFY `codFornecedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `livro`
--
ALTER TABLE `livro`
  MODIFY `codLivro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `pagamento`
--
ALTER TABLE `pagamento`
  MODIFY `codPagamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `livro`
--
ALTER TABLE `livro`
  ADD CONSTRAINT `fk_clientex` FOREIGN KEY (`codCliente`) REFERENCES `cliente` (`codCliente`),
  ADD CONSTRAINT `fk_fornecedor` FOREIGN KEY (`codFornecedor`) REFERENCES `fornecedor` (`codFornecedor`);

--
-- Limitadores para a tabela `pagamento`
--
ALTER TABLE `pagamento`
  ADD CONSTRAINT `fk_cliente` FOREIGN KEY (`codCliente`) REFERENCES `cliente` (`codCliente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
