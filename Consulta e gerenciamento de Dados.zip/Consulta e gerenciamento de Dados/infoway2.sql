-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 05-Fev-2020 às 15:50
-- Versão do servidor: 10.1.38-MariaDB
-- versão do PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `infoway2`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `aluno`
--

CREATE TABLE `aluno` (
  `matricula` int(11) NOT NULL,
  `nome_aluno` varchar(100) DEFAULT NULL,
  `endereço_completo` varchar(100) DEFAULT NULL,
  `nome_pai` varchar(100) DEFAULT NULL,
  `nome_mãe` varchar(100) DEFAULT NULL,
  `cpf` varchar(100) DEFAULT NULL,
  `telefone` varchar(100) DEFAULT NULL,
  `rg` varchar(100) DEFAULT NULL,
  `prova01` varchar(100) DEFAULT NULL,
  `prova02` varchar(100) DEFAULT NULL,
  `atributo_bimestral` varchar(100) DEFAULT NULL,
  `cod_curso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `aluno`
--

INSERT INTO `aluno` (`matricula`, `nome_aluno`, `endereço_completo`, `nome_pai`, `nome_mãe`, `cpf`, `telefone`, `rg`, `prova01`, `prova02`, `atributo_bimestral`, `cod_curso`) VALUES
(1, 'clayton oliveira', 'rua rego grande 42 - mangueira', 'paulo cesar de oliveira', 'eva maria da silva oliveira', '12345678910', '12345678', '123456789', '9.2', '9.3', NULL, 1),
(2, 'amanda silva', 'rua rego grande 42 - benfica', 'jose cesar de oliveira', 'santa velha da silva oliveira', '12345678910', '12345678', '123456789', '9.2', '9.3', NULL, 1),
(3, 'dougrlas', 'rua rego magro 71 - bananal', 'antonio dogras', 'maria dogras oliveira', '12345678', '12345678', '123456789', '9.2', '9.7', NULL, 1),
(4, 'rudsong', 'rua rego gordinho 42 - mangueira', 'jose rudsong', 'maria rudsong ', '12345678910', '12345678', '123456789', '9.2', '9.3', NULL, 3),
(5, 'victor emanuel', 'rua rego vozerao 42 - mangueira', 'paulo cesar de oliveira', 'eva maria da silva oliveira', '12345678910', '12345678', '123456789', '9.2', '9.0', NULL, 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `idCliente` int(11) NOT NULL,
  `nomeCliente` varchar(100) DEFAULT NULL,
  `cpfCliente` varchar(15) DEFAULT NULL,
  `rua` varchar(100) DEFAULT NULL,
  `complemento` varchar(100) DEFAULT NULL,
  `bairro` varchar(100) DEFAULT NULL,
  `cep` varchar(11) DEFAULT NULL,
  `municipio` varchar(100) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`idCliente`, `nomeCliente`, `cpfCliente`, `rua`, `complemento`, `bairro`, `cep`, `municipio`, `estado`, `numero`) VALUES
(1, 'Clayton Rine', '12726537377', 'Dos doidos', 'bloco 2', 'Benfica', '123456789', 'rio de janeiro', 'RJ', 13),
(2, 'Michael Douglas', '4456476657', 'Dos sants', 'bloco 4', 'piam', '5645778', 'Belford Roxo', 'RJ', 13),
(3, 'Adriano ', '43242424234', 'ABC', 'bloco 0', 'piam', '343424', 'Belfor Roxo', 'RJ', 13),
(4, 'Hudson Nascimento', '34343242556', 'Dos santos', 'bloco 5', 'centro', '534535345', 'Nova Iguaçu', 'RJ', 13),
(5, 'Adolfo hitler', '5555666', 'nazista', 'bloco 8', 'sei la', '9382744', 'nova iguaçu', 'RJ', 13),
(6, 'danilao', '3333333', 'brabo', 'bloco 00', 'vela velha', '3334255', 'mesquita', 'RJ', 13);

-- --------------------------------------------------------

--
-- Estrutura da tabela `curso`
--

CREATE TABLE `curso` (
  `cod_curso` int(11) NOT NULL,
  `nome_curso` varchar(100) DEFAULT NULL,
  `carga_horaria` varchar(100) DEFAULT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_termino` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `curso`
--

INSERT INTO `curso` (`cod_curso`, `nome_curso`, `carga_horaria`, `data_inicio`, `data_termino`) VALUES
(1, 'Analise de Sistemas', '1000 horas', '2020-02-15', '2020-12-15'),
(2, 'teste de software', '200 horas', '2020-02-20', '2020-11-13'),
(3, 'tecnico em informati', '1000 horas', '2020-01-20', '2020-11-29'),
(4, 'Programador', '30 horas', '0000-00-00', '2020-10-20'),
(5, 'rede', '120 horas', '2020-04-09', '2020-11-13');

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplina`
--

CREATE TABLE `disciplina` (
  `cod_disciplina` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `carga_horaria` varchar(100) DEFAULT NULL,
  `cod_curso` int(11) DEFAULT NULL,
  `cod_professor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `disciplina`
--

INSERT INTO `disciplina` (`cod_disciplina`, `nome`, `carga_horaria`, `cod_curso`, `cod_professor`) VALUES
(3, 'logica de programaçã', '40 horas', NULL, NULL),
(4, 'tecnico em informa', '42 horas', NULL, NULL),
(5, 'Suporte', '10horas', NULL, NULL),
(6, 'logica ', '50horas', NULL, NULL),
(7, 'teste de software', '60horas', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamento`
--

CREATE TABLE `pagamento` (
  `cod_pagamento` int(11) NOT NULL,
  `data_pagamento` date DEFAULT NULL,
  `valor` double DEFAULT NULL,
  `forma_pagamento` varchar(100) DEFAULT NULL,
  `descricao_pagamento` varchar(200) DEFAULT NULL,
  `matricula` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `pagamento`
--

INSERT INTO `pagamento` (`cod_pagamento`, `data_pagamento`, `valor`, `forma_pagamento`, `descricao_pagamento`, `matricula`) VALUES
(1, '2020-02-03', 5000, 'dinheiro', 'referente ao curso de analise', NULL),
(2, '2020-02-03', 1500, 'cartão de credito', 'progamador', NULL),
(3, '2020-02-03', 5000, 'Cartão de Debito', 'desenvolverdor de sistemas ', NULL),
(4, '2020-02-03', 1000, 'dinheiro', 'html css3', NULL),
(5, '2020-02-03', 1300, 'dinheiro', 'Suporte de rede', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `professor`
--

CREATE TABLE `professor` (
  `cod_professor` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `rg` varchar(20) DEFAULT NULL,
  `cpf` varchar(20) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `habilitacao_tecnica` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `professor`
--

INSERT INTO `professor` (`cod_professor`, `nome`, `rg`, `cpf`, `telefone`, `habilitacao_tecnica`) VALUES
(1, 'jose barbosa', '1234567789', '1638636493', '187465409', 'Infra rede'),
(4, 'douglas oliveira', '1234576', '33847469', '187465409', 'JAVA'),
(5, 'hudson', '34324234', '1038734646', '4332432434', 'Programação'),
(6, 'Adriano ', '343787984234', '909808900', '453645677', 'TI Basico'),
(7, 'danilo', '5464646', '546466556', '98594537665', 'analista');

-- --------------------------------------------------------

--
-- Estrutura da tabela `turma`
--

CREATE TABLE `turma` (
  `numero_turma` int(11) NOT NULL,
  `cod_curso` int(11) DEFAULT NULL,
  `sala` int(11) DEFAULT NULL,
  `horario` varchar(10) DEFAULT NULL,
  `cadeira` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `turma`
--

INSERT INTO `turma` (`numero_turma`, `cod_curso`, `sala`, `horario`, `cadeira`) VALUES
(1, NULL, 301, '18:00 h', 20);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`matricula`),
  ADD KEY `cod_curso` (`cod_curso`);

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idCliente`);

--
-- Indexes for table `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`cod_curso`);

--
-- Indexes for table `disciplina`
--
ALTER TABLE `disciplina`
  ADD PRIMARY KEY (`cod_disciplina`),
  ADD KEY `fk_disciplina` (`cod_curso`),
  ADD KEY `cod_professor` (`cod_professor`);

--
-- Indexes for table `pagamento`
--
ALTER TABLE `pagamento`
  ADD PRIMARY KEY (`cod_pagamento`),
  ADD KEY `fk_pagamento` (`matricula`);

--
-- Indexes for table `professor`
--
ALTER TABLE `professor`
  ADD PRIMARY KEY (`cod_professor`),
  ADD UNIQUE KEY `rg` (`rg`),
  ADD UNIQUE KEY `cpf` (`cpf`);

--
-- Indexes for table `turma`
--
ALTER TABLE `turma`
  ADD PRIMARY KEY (`numero_turma`),
  ADD KEY `fk_turma` (`cod_curso`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aluno`
--
ALTER TABLE `aluno`
  MODIFY `matricula` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `curso`
--
ALTER TABLE `curso`
  MODIFY `cod_curso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `disciplina`
--
ALTER TABLE `disciplina`
  MODIFY `cod_disciplina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pagamento`
--
ALTER TABLE `pagamento`
  MODIFY `cod_pagamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `professor`
--
ALTER TABLE `professor`
  MODIFY `cod_professor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `turma`
--
ALTER TABLE `turma`
  MODIFY `numero_turma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `aluno`
--
ALTER TABLE `aluno`
  ADD CONSTRAINT `aluno_ibfk_1` FOREIGN KEY (`cod_curso`) REFERENCES `curso` (`cod_curso`);

--
-- Limitadores para a tabela `disciplina`
--
ALTER TABLE `disciplina`
  ADD CONSTRAINT `disciplina_ibfk_1` FOREIGN KEY (`cod_professor`) REFERENCES `professor` (`cod_professor`),
  ADD CONSTRAINT `fk_disciplina` FOREIGN KEY (`cod_curso`) REFERENCES `curso` (`cod_curso`);

--
-- Limitadores para a tabela `pagamento`
--
ALTER TABLE `pagamento`
  ADD CONSTRAINT `fk_pagamento` FOREIGN KEY (`matricula`) REFERENCES `aluno` (`matricula`);

--
-- Limitadores para a tabela `turma`
--
ALTER TABLE `turma`
  ADD CONSTRAINT `fk_turma` FOREIGN KEY (`cod_curso`) REFERENCES `curso` (`cod_curso`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
